# main.py

import pandas as pd
from analyzer.load_data import load_csv
from analyzer.clean_data import clean_listing_data
from analyzer.analysis import (
    median_price_by_neighborhood,
    mean_price_by_neighborhood,
    median_price_by_room_type,
    mean_price_by_room_type,
    min_price_by_neighborhood,
    max_price_by_neighborhood,
    count_by_room_type,
)
from analyzer.outlier import detect_price_outliers
from analyzer.visualize import (
    plot_price_distribution,
    plot_boxplot_by_neighborhood,
    plot_avg_price_by_room_type,
    plot_outliers,
)


def main():
    print("📦 Airbnb Listings Analyzer Started\n")

    # 1. Load Data
    file_path = "listings.csv"
    print("📂 Loading data...")
    df = load_csv(file_path)
    print(f"✅ Data loaded successfully. Shape: {df.shape}\n")

    # 2. Clean Data
    print("🧹 Cleaning data...")
    df = clean_listing_data(df)
    print("✅ Data cleaned.\n")

    # 3. Analysis
    print("📊 Running analysis...\n")

    print("🔝 Most Expensive Neighborhoods (Median):")
    print(
        median_price_by_neighborhood(df).sort_values(ascending=False).head(5),
        end="\n\n",
    )

    print("💰 Cheapest Neighborhoods (Median):")
    print(median_price_by_neighborhood(df).sort_values().head(5), end="\n\n")

    print("🏠 Average Price by Room Type:")
    print(mean_price_by_room_type(df), end="\n\n")

    print("📉 Minimum Price by Neighborhood:")
    print(min_price_by_neighborhood(df).sort_values().head(5), end="\n\n")

    print("📈 Maximum Price by Neighborhood:")
    print(
        max_price_by_neighborhood(df).sort_values(ascending=False).head(5), end="\n\n"
    )

    print("📦 Room Type Distribution:")
    print(count_by_room_type(df), end="\n\n")

    print("✅ Analysis Complete.\n")

    # 4. Outlier Detection
    outliers = detect_price_outliers(df)
    print("🚨 Detected Price Outliers:")
    print(
        outliers[["neighbourhood", "room_type", "price"]]
        .sort_values(by="price", ascending=False)
        .head(10)
    )

    print("✅ Outlier Detection Complete.")

    # 📊 Visualizations
    plot_price_distribution(df)
    plot_boxplot_by_neighborhood(df)
    plot_avg_price_by_room_type(df)
    plot_outliers(outliers)


if __name__ == "__main__":
    main()
