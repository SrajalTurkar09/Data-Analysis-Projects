def median_price_by_neighbourhood(df):
    return df.groupby("neighbourhood")["price"].median()


def mean_price_by_room_type(df):
    return df.groupby("room_type")["price"].mean()


def min_price_by_neighbourhood(df):
    return df.groupby("neighbourhood")["price"].min()


def max_price_by_neighbourhood(df):
    return df.groupby("neighbourhood")["price"].max()


def count_by_room_type(df):
    return df.groupby("room_type")["price"].count()
