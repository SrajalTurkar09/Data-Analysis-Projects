import pandas as pd
import numpy as np


def load_csv(file_path: str):
    return pd.read_csv(file_path)
