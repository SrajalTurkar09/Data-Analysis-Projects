def clean_listing_data(df):
    """
    Cleans Airbnb listings DataFrame:
    1. Cleans and converts price to float
    2. Fills nulls where appropriate, drops only critical nulls
    3. Removes duplicates
    4. Drops rows with invalid price (price <= 0)
    """

    df = df.copy()

    # Step 1: Clean 'price' column — remove $, commas, and convert to float
    df["price"] = (
        df["price"]
        .astype(str)
        .str.replace("$", "", regex=False)
        .str.replace(",", "", regex=False)
        .astype(float)
    )

    # Step 2: Remove duplicates
    df = df.drop_duplicates()

    # Step 3: Fill missing reviews per month with 0
    if "reviews_per_month" in df.columns:
        df["reviews_per_month"] = df["reviews_per_month"].fillna(0)

    # Step 4: Drop rows with missing important values
    df = df.dropna(subset=["neighbourhood", "room_type", "price"])

    # Step 5: Drop rows with price <= 0
    df = df[df["price"] > 0]

    return df
