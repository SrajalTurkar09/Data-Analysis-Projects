from flask import Flask, render_template, request
import pandas as pd
import base64
from io import BytesIO

from analyzer.clean_data import clean_listing_data
from analyzer.analysis import (
    mean_price_by_room_type,
    median_price_by_neighborhood,
    max_price_by_neighborhood,
    min_price_by_neighborhood,
    count_by_room_type,
)
from analyzer.outlier import detect_price_outliers
from analyzer.visualize import (
    plot_price_distribution,
    plot_boxplot_by_neighborhood,
    plot_avg_price_by_room_type,
    plot_outliers,
)

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    file = request.files.get("csvfile")
    if not file:
        return "<div style='color:red'><b>Error:</b> No file uploaded.</div>", 400

    try:
        df = pd.read_csv(file)
    except Exception as e:
        return f"<div style='color:red'><b>Error reading CSV:</b> {e}</div>", 400

    try:
        df = clean_listing_data(df)
    except Exception as e:
        return f"<div style='color:red'><b>Data cleaning error:</b> {e}</div>", 400

    # Analysis
    try:
        mean_prices = mean_price_by_room_type(df).to_dict()
        med_prices = (
            median_price_by_neighborhood(df)
            .sort_values(ascending=False)
            .head(5)
            .to_dict()
        )
        min_prices = min_price_by_neighborhood(df).sort_values().head(5).to_dict()
        max_prices = (
            max_price_by_neighborhood(df).sort_values(ascending=False).head(5).to_dict()
        )
        room_type_counts = count_by_room_type(df).to_dict()
        outliers = detect_price_outliers(df)
        outlier_rows = (
            outliers[["neighbourhood", "room_type", "price"]]
            .sort_values(by="price", ascending=False)
            .head(5)
        )
    except Exception as e:
        return f"<div style='color:red'><b>Analysis error:</b> {e}</div>", 500

    # Generate HTML result
    result_html = "<h2>📊 Analysis Results</h2>"

    # Stats
    result_html += "<h3>📦 Room Type Distribution</h3><ul>"
    for room, count in room_type_counts.items():
        result_html += f"<li>{room}: <b>{count}</b> listings</li>"
    result_html += "</ul>"

    result_html += "<h3>🏠 Mean Price by Room Type</h3><ul>"
    for room, price in mean_prices.items():
        result_html += f"<li>{room}: <b>${price:.2f}</b></li>"
    result_html += "</ul>"

    result_html += "<h3>🔝 Most Expensive Neighborhoods (Median)</h3><ul>"
    for n, p in med_prices.items():
        result_html += f"<li>{n}: <b>${p:.2f}</b></li>"
    result_html += "</ul>"

    result_html += "<h3>💰 Cheapest Neighborhoods (Minimum)</h3><ul>"
    for n, p in min_prices.items():
        result_html += f"<li>{n}: <b>${p:.2f}</b></li>"
    result_html += "</ul>"

    result_html += "<h3>💸 Most Expensive Neighborhoods (Maximum)</h3><ul>"
    for n, p in max_prices.items():
        result_html += f"<li>{n}: <b>${p:.2f}</b></li>"
    result_html += "</ul>"

    # Outlier Table
    result_html += "<h3>🚨 Top Price Outliers</h3>"
    if not outlier_rows.empty:
        result_html += "<table style='width:100%;border-collapse:collapse;'>"
        result_html += "<tr><th>Neighborhood</th><th>Room Type</th><th>Price</th></tr>"
        for _, row in outlier_rows.iterrows():
            result_html += f"<tr><td>{row['neighbourhood']}</td><td>{row['room_type']}</td><td><b>${row['price']:.2f}</b></td></tr>"
        result_html += "</table>"
    else:
        result_html += "<div>No significant price outliers detected.</div>"

    return result_html


if __name__ == "__main__":
    app.run(debug=True)
