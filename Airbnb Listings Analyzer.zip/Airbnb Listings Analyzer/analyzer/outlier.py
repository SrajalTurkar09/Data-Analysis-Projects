def detect_price_outliers(df):
    """
    Identifies rows where 'price' is an outlier using IQR method.
    Returns a DataFrame with only outliers.
    """
    q1 = df["price"].quantile(0.25)
    q3 = df["price"].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr

    return df[(df["price"] < lower_bound) | (df["price"] > upper_bound)]

    # df_outliers = df[(df["price"] < lower_bound) | (df["price"] > upper_bound)]
    # return df_outliers
