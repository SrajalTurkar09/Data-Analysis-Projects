#  Goal: Analyze neighborhoods and room types


def median_price_by_neighborhood(df):
    df_grouped = df.groupby("neighbourhood")

    return df_grouped["price"].median()


def median_price_by_room_type(df):
    df_grouped = df.groupby("room_type")

    return df_grouped["price"].median()


def mean_price_by_room_type(df):
    df_grouped = df.groupby("room_type")

    return df_grouped["price"].mean()


def mean_price_by_neighborhood(df):
    df_grouped = df.groupby("neighbourhood")

    return df_grouped["price"].mean()


def min_price_by_room_type(df):
    df_grouped = df.groupby("room_type")

    return df_grouped["price"].min()


def min_price_by_neighborhood(df):
    df_grouped = df.groupby("neighbourhood")

    return df_grouped["price"].min()


def max_price_by_room_type(df):
    df_grouped = df.groupby("room_type")

    return df_grouped["price"].max()


def max_price_by_neighborhood(df):
    df_grouped = df.groupby("neighbourhood")

    return df_grouped["price"].max()


def count_by_room_type(df):
    df_grouped = df.groupby("room_type")

    return df_grouped["price"].count()


"""

summary about all functions

1. median_price_by_neighborhood
2. median_price_by_room_type
3. mean_price_by_room_type
4. mean_price_by_neighborhood
5. min_price_by_room_type
6. min_price_by_neighborhood
7. max_price_by_room_type
8. max_price_by_neighborhood
9. count_by_room_type


# now see which one what to do



"""
