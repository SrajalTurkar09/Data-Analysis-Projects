import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")


def plot_price_distribution(df):
    plt.figure(figsize=(10, 6))
    sns.histplot(df["price"], bins=50, kde=True)
    plt.title("Price Distribution")
    plt.xlabel("Price")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.show()


def plot_boxplot_by_neighborhood(df):
    plt.figure(figsize=(12, 6))
    top_neigh = df["neighbourhood"].value_counts().head(10).index
    sns.boxplot(
        x="neighbourhood", y="price", data=df[df["neighbourhood"].isin(top_neigh)]
    )
    plt.xticks(rotation=45)
    plt.title("Price Distribution by Neighborhood (Top 10)")
    plt.tight_layout()
    plt.show()


def plot_avg_price_by_room_type(df):
    plt.figure(figsize=(8, 5))
    avg_prices = df.groupby("room_type")["price"].mean().sort_values(ascending=False)
    sns.barplot(x=avg_prices.index, y=avg_prices.values)
    plt.title("Average Price by Room Type")
    plt.ylabel("Average Price")
    plt.xlabel("Room Type")
    plt.tight_layout()
    plt.show()


def plot_outliers(outliers_df):
    plt.figure(figsize=(10, 6))
    sns.stripplot(
        x="room_type", y="price", data=outliers_df, jitter=True, palette="Reds"
    )
    plt.title("Price Outliers by Room Type")
    plt.ylabel("Outlier Price")
    plt.xlabel("Room Type")
    plt.tight_layout()
    plt.show()
